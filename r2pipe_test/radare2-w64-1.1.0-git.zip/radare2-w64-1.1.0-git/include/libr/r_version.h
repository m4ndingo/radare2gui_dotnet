#ifndef R_VERSION_H
#define R_VERSION_H 1
#define R2_VERSION_COMMIT 13111
#define R2_GITTAP "1.0.2-167-g81c0cf5"
#define R2_GITTIP "81c0cf5a9d863e8e0f203eed39c5ebd2bc219f53"
#define R2_BIRTH "2016-11-25"
#endif
