#ifndef R_VERSION_H
#define R_VERSION_H 1
#define R2_VERSION_COMMIT 13186
#define R2_GITTAP "1.0.2-241-gfaec18b"
#define R2_GITTIP "faec18b74b8e6d28db361751dd8200a0af511df3"
#define R2_BIRTH "2016-12-12"
#endif
