#ifndef R_LOG_H
#define R_LOG_H

R_API void r_log_msg(const char *str);
R_API void r_log_error(const char *str);
R_API void r_log_file(const char *str);
R_API void r_log_progress(const char *str, int percent);
#endif //  R_LOG_H
